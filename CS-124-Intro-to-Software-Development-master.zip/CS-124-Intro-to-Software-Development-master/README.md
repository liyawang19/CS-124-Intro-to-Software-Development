# CS-124 Intro to Software Development
# CS-124 Projects Overview
#
In this class, students are encouraged to create their own projects. In our team of four, we decided that our projects are to help students accomplish the learning objectives of the class and learn the principles of basic programming in C++ while still having fun.

#Project1 - Averaging Grades
We created this project because we wanted to allow students the opportunity to perform a practical task (especially for students) in a fun way by learning how to code a program that would calculate their grades.
 
#Project2 - Mad Lib
This game is designed to soothe students' stress from this class and immerse themselves in a different kind of logic, and have fun programming a game they can play with their friends and family.

#Project3 - Sudoku
This game is designed to puzzle students' minds with numbers so that they can get to know what the computer can do. The goal is to fill 3 x 3 boxes with numbers ranging from 1-9.The coolest part about our Sudoku is that each box has 3x3 grids, which makes this Sudoku more challenging.


#Material of This Course:

-Input & Output

-Data

-IF Statements

-Function Design

-Loops

-Files

-Arrays

-Pointers

-Conditionals
